/*
	TestUnit.h - Library for test unit of Practice(Program)
	Created by naivecao. Novemeber 8, 2015
	Lasted modified by naivecao. Novemeber 8, 2015
    Co,.Ltd:Lcmj
 */


// avoid head files multiple references
#ifndef TestUnit_h
#define TestUnit_h
 
#include "Arduino.h"
 
class TestUnit
{
  public:
    TestUnit(int pin);
    void dot();
    void dash();
  private:
    int _pin;
};
 
#endif