/*
	TestUnit.cpp - Library for test unit of Practice(Program)
	Created by naivecao. Novemeber 8, 2015
	Lasted modified by naivecao. Novemeber 8, 2015
    Co,.Ltd:Lcmj
 */


// include head files
#include "Arduino.h"
#include "TestUnit.h"


// check serial port state
TestUnit::TestUnit(int pin)
{
	Serial.begin(9600);
	if(Serial)
	{
		
	}
}
 
void TestUnit::dot()
{
  digitalWrite(_pin, HIGH);
  delay(250);
  digitalWrite(_pin, LOW);
  delay(250);  
}
 
void TestUnit::dash()
{
  digitalWrite(_pin, HIGH);
  delay(1000);
  digitalWrite(_pin, LOW);
  delay(250);
}